<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard Pembeli') }}
        </h2>
    </x-slot>

    <div class="py-6 sm:py-12 bg-gray-100 min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            {{-- Bagian Sambutan & Profil Ringkas --}}
            <div class="bg-gradient-to-r from-blue-600 to-blue-800 text-white overflow-hidden shadow-lg sm:rounded-lg mb-6 p-6 md:p-8 flex items-center justify-between">
                <div>
                    <h3 class="text-3xl md:text-4xl font-bold mb-1">
                        Halo, {{ Auth::user()->name }}!
                    </h3>
                    <p class="text-blue-100 text-lg">
                        Selamat datang di halaman dashboard Anda.
                    </p>
                </div>
                <div class="flex items-center">
                    {{-- Avatar Pengguna (Opsional, bisa ditambahkan nanti) --}}
                    <img class="w-16 h-16 rounded-full border-2 border-white mr-4" src="https://ui-avatars.com/api/?name={{ urlencode(Auth::user()->name) }}&color=7F9CF5&background=EBF4FF" alt="Avatar">
                    <div>
                        <p class="font-semibold text-white">{{ Auth::user()->email }}</p>
                        <a href="{{ route('profile.edit') }}" class="text-blue-200 hover:underline text-sm">Lihat Profil</a>
                    </div>
                </div>
            </div>

            {{-- Bagian Statistik Cepat (ala Shopee) --}}
            <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
                <div class="bg-white rounded-lg shadow-md p-5 flex items-center justify-between transition-transform transform hover:scale-105">
                    <div>
                        <p class="text-sm text-gray-500 font-medium">Pesanan Menunggu</p>
                        <p class="text-2xl font-bold text-blue-700 mt-1">
                            {{-- Contoh data dummy, ganti dengan data real --}}
                            {{ Auth::user()->orders()->where('status', 'diproses')->count() }}
                        </p>
                    </div>
                    <i class="fas fa-box-open text-3xl text-blue-400"></i> {{-- Icon Pesanan --}}
                </div>
                <div class="bg-white rounded-lg shadow-md p-5 flex items-center justify-between transition-transform transform hover:scale-105">
                    <div>
                        <p class="text-sm text-gray-500 font-medium">Pesanan Diproses</p>
                        <p class="text-2xl font-bold text-yellow-500 mt-1">
                            {{ Auth::user()->orders()->where('status', 'diproses')->count() }}
                        </p>
                    </div>
                    <i class="fas fa-truck text-3xl text-yellow-400"></i> {{-- Icon Pengiriman --}}
                </div>
                <div class="bg-white rounded-lg shadow-md p-5 flex items-center justify-between transition-transform transform hover:scale-105">
                    <div>
                        <p class="text-sm text-gray-500 font-medium">Pesanan Selesai</p>
                        <p class="text-2xl font-bold text-green-600 mt-1">
                            {{ Auth::user()->orders()->where('status', 'selesai')->count() }}
                        </p>
                    </div>
                    <i class="fas fa-check-circle text-3xl text-green-400"></i> {{-- Icon Selesai --}}
                </div>
                <div class="bg-white rounded-lg shadow-md p-5 flex items-center justify-between transition-transform transform hover:scale-105">
                    <div>
                        <p class="text-sm text-gray-500 font-medium">Notifikasi</p>
                        <p class="text-2xl font-bold text-red-600 mt-1">
                            {{-- Contoh data dummy, ganti dengan data real --}}
                            0
                        </p>
                    </div>
                    <i class="fas fa-bell text-3xl text-red-400"></i> {{-- Icon Notifikasi --}}
                </div>
            </div>

            {{-- Bagian Menu Shortcut (Icon-icon) --}}
            <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                <h4 class="text-lg font-semibold mb-4 text-gray-800">Akses Cepat</h4>
                <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6 text-center">
                    <a href="#" class="block p-4 rounded-lg hover:bg-blue-50 transition">
                        <i class="fas fa-shopping-bag text-blue-600 text-3xl mb-2"></i>
                        <p class="text-sm text-gray-700 font-medium">Pesanan Saya</p>
                    </a>
                    <a href="#" class="block p-4 rounded-lg hover:bg-blue-50 transition">
                        <i class="fas fa-heart text-red-500 text-3xl mb-2"></i>
                        <p class="text-sm text-gray-700 font-medium">Wishlist</p>
                    </a>
                    <a href="#" class="block p-4 rounded-lg hover:bg-blue-50 transition">
                        <i class="fas fa-credit-card text-green-600 text-3xl mb-2"></i>
                        <p class="text-sm text-gray-700 font-medium">Pembayaran</p>
                    </a>
                    <a href="#" class="block p-4 rounded-lg hover:bg-blue-50 transition">
                        <i class="fas fa-star text-yellow-500 text-3xl mb-2"></i>
                        <p class="text-sm text-gray-700 font-medium">Ulasan Saya</p>
                    </a>
                    <a href="#" class="block p-4 rounded-lg hover:bg-blue-50 transition">
                        <i class="fas fa-ticket-alt text-purple-600 text-3xl mb-2"></i>
                        <p class="text-sm text-gray-700 font-medium">Voucher</p>
                    </a>
                    <a href="{{ route('profile.edit') }}" class="block p-4 rounded-lg hover:bg-blue-50 transition">
                        <i class="fas fa-user-circle text-gray-600 text-3xl mb-2"></i>
                        <p class="text-sm text-gray-700 font-medium">Pengaturan</p>
                    </a>
                </div>
            </div>

            {{-- Bagian Daftar Pesanan --}}
            <div class="bg-white overflow-hidden shadow-md sm:rounded-lg">
                <div class="p-6">
                    <h4 class="text-lg font-semibold mb-4 text-gray-800">Riwayat 5 Pesanan Terakhir</h4>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Pesanan</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @forelse($orders as $order)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#{{ $order->id }}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Rp {{ number_format($order->total, 0, ',', '.') }}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold {{ 
                                                $order->status == 'selesai' ? 'text-green-600' : 
                                                ($order->status == 'diproses' ? 'text-yellow-600' : 
                                                'text-blue-600') 
                                            }} capitalize">{{ $order->status }}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $order->created_at->format('d M Y') }}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <a href="#" class="text-blue-600 hover:text-blue-900">Detail</a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                                            Anda belum memiliki pesanan.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</x-app-layout>